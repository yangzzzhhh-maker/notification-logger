# Keep notification service
-keep class com.example.notificationlogger.NotificationMonitorService { *; }
