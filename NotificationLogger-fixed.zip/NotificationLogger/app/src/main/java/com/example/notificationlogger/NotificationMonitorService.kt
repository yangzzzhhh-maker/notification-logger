package com.example.notificationlogger

import android.app.Notification
import android.content.Intent
import android.content.pm.PackageManager
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.util.Log

class NotificationMonitorService : NotificationListenerService() {

    companion object {
        const val ACTION_LOG_UPDATED = "com.example.notificationlogger.LOG_UPDATED"
        private const val TAG = "NotifMonitor"
    }

    private lateinit var db: DatabaseHelper

    override fun onCreate() {
        super.onCreate()
        db = DatabaseHelper(this)
        Log.i(TAG, "Service created")
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        if (sbn == null) return
        if (packageName == sbn.packageName) return

        try {
            val notification = sbn.notification ?: return
            val extras = notification.extras ?: return

            val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
            val bigText = extras.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString()
            val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString()
            val subText = extras.getCharSequence(Notification.EXTRA_SUB_TEXT)?.toString()

            var content = when {
                !bigText.isNullOrBlank() -> bigText
                !text.isNullOrBlank() -> text
                else -> ""
            }
            if (!subText.isNullOrBlank()) {
                content = if (content.isEmpty()) subText else "$content\n$subText"
            }

            if (title.isEmpty() && content.isEmpty()) return

            val pkg = sbn.packageName
            val appName = getAppName(pkg)
            val timestamp = if (sbn.postTime > 0) sbn.postTime else System.currentTimeMillis()

            db.insert(timestamp, pkg, appName, title, content, sbn.id)
            sendBroadcast(Intent(ACTION_LOG_UPDATED))
        } catch (e: Exception) {
            Log.e(TAG, "Error processing notification", e)
        }
    }

    private fun getAppName(packageName: String): String {
        return try {
            val ai = packageManager.getApplicationInfo(packageName, 0)
            packageManager.getApplicationLabel(ai).toString()
        } catch (_: PackageManager.NameNotFoundException) {
            packageName
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        db.close()
    }
}
