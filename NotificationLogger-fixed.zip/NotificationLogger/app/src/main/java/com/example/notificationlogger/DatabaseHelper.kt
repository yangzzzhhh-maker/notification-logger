package com.example.notificationlogger

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

data class NotificationLog(
    val id: Long = 0,
    val timestamp: Long,
    val packageName: String,
    val appName: String,
    val title: String,
    val content: String,
    val notificationId: Int
)

class DatabaseHelper(context: Context) : SQLiteOpenHelper(context, DB_NAME, null, DB_VERSION) {

    companion object {
        private const val DB_NAME = "notification_logs.db"
        private const val DB_VERSION = 1
        private const val TABLE = "logs"
        private const val COL_ID = "_id"
        private const val COL_TS = "timestamp"
        private const val COL_PKG = "package_name"
        private const val COL_APP = "app_name"
        private const val COL_TITLE = "title"
        private const val COL_CONTENT = "content"
        private const val COL_NID = "notification_id"
    }

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            """
            CREATE TABLE $TABLE (
                $COL_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                $COL_TS INTEGER NOT NULL,
                $COL_PKG TEXT NOT NULL,
                $COL_APP TEXT,
                $COL_TITLE TEXT,
                $COL_CONTENT TEXT,
                $COL_NID INTEGER
            )
            """.trimIndent()
        )
        db.execSQL("CREATE INDEX idx_ts ON $TABLE($COL_TS DESC)")
        db.execSQL("CREATE INDEX idx_pkg ON $TABLE($COL_PKG)")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS $TABLE")
        onCreate(db)
    }

    fun insert(
        timestamp: Long,
        packageName: String,
        appName: String,
        title: String,
        content: String,
        notificationId: Int
    ): Long {
        val values = ContentValues().apply {
            put(COL_TS, timestamp)
            put(COL_PKG, packageName)
            put(COL_APP, appName)
            put(COL_TITLE, title)
            put(COL_CONTENT, content)
            put(COL_NID, notificationId)
        }
        return writableDatabase.insert(TABLE, null, values)
    }

    fun getLogs(packageFilter: String?): List<NotificationLog> {
        val list = mutableListOf<NotificationLog>()
        val db = readableDatabase
        val cursor = if (!packageFilter.isNullOrEmpty()) {
            db.query(TABLE, null, "$COL_PKG=?", arrayOf(packageFilter), null, null, "$COL_TS DESC")
        } else {
            db.query(TABLE, null, null, null, null, null, "$COL_TS DESC")
        }
        cursor?.use {
            while (it.moveToNext()) {
                list.add(
                    NotificationLog(
                        id = it.getLong(it.getColumnIndexOrThrow(COL_ID)),
                        timestamp = it.getLong(it.getColumnIndexOrThrow(COL_TS)),
                        packageName = it.getString(it.getColumnIndexOrThrow(COL_PKG)),
                        appName = it.getString(it.getColumnIndexOrThrow(COL_APP)) ?: "",
                        title = it.getString(it.getColumnIndexOrThrow(COL_TITLE)) ?: "",
                        content = it.getString(it.getColumnIndexOrThrow(COL_CONTENT)) ?: "",
                        notificationId = it.getInt(it.getColumnIndexOrThrow(COL_NID))
                    )
                )
            }
        }
        return list
    }

    fun getDistinctPackages(): List<String> {
        val list = mutableListOf<String>()
        readableDatabase.rawQuery(
            "SELECT $COL_PKG, MAX($COL_TS) AS last_ts FROM $TABLE GROUP BY $COL_PKG ORDER BY last_ts DESC",
            null
        )?.use {
            while (it.moveToNext()) {
                list.add(it.getString(0))
            }
        }
        return list
    }

    fun clearAll() {
        writableDatabase.delete(TABLE, null, null)
    }

    fun clearByPackage(packageName: String) {
        if (packageName.isEmpty()) clearAll()
        else writableDatabase.delete(TABLE, "$COL_PKG=?", arrayOf(packageName))
    }
}
