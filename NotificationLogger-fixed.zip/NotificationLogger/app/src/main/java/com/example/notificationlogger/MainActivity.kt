package com.example.notificationlogger

import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Bundle
import android.provider.Settings
import android.text.TextUtils
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.MenuAnchorType
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.kyant.backdrop.backdrops.layerBackdrop
import com.kyant.backdrop.backdrops.rememberLayerBackdrop
import com.kyant.backdrop.drawBackdrop
import com.kyant.backdrop.effects.blur
import com.kyant.backdrop.effects.lens
import com.kyant.backdrop.effects.vibrancy
import com.kyant.shapes.Capsule
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {

    private lateinit var db: DatabaseHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        db = DatabaseHelper(this)

        setContent {
            NotificationLoggerTheme {
                NotificationLoggerApp(db = db)
            }
        }
    }
}

@Composable
fun NotificationLoggerTheme(content: @Composable () -> Unit) {
    val context = LocalContext.current
    val dark = isSystemInDarkTheme()
    val colorScheme = remember(dark) {
        if (dark) {
            try {
                dynamicDarkColorScheme(context)
            } catch (_: Throwable) {
                darkColorScheme()
            }
        } else {
            try {
                dynamicLightColorScheme(context)
            } catch (_: Throwable) {
                lightColorScheme()
            }
        }
    }
    MaterialTheme(colorScheme = colorScheme, content = content)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NotificationLoggerApp(db: DatabaseHelper) {
    val context = LocalContext.current
    var logs by remember { mutableStateOf(db.getLogs(null)) }
    var packages by remember { mutableStateOf(db.getDistinctPackages()) }
    var selectedPackage by remember { mutableStateOf<String?>(null) }
    var listenerEnabled by remember { mutableStateOf(isNotificationServiceEnabled(context)) }
    var showClearDialog by remember { mutableStateOf(false) }
    var detailLog by remember { mutableStateOf<NotificationLog?>(null) }
    var filterExpanded by remember { mutableStateOf(false) }

    fun reload() {
        packages = db.getDistinctPackages()
        logs = db.getLogs(selectedPackage)
        listenerEnabled = isNotificationServiceEnabled(context)
    }

    // 监听新通知广播
    DisposableEffect(Unit) {
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(c: Context?, intent: Intent?) {
                reload()
            }
        }
        val filter = IntentFilter(NotificationMonitorService.ACTION_LOG_UPDATED)
        try {
            ContextCompat.registerReceiver(
                context, receiver, filter, ContextCompat.RECEIVER_NOT_EXPORTED
            )
        } catch (_: Throwable) {
            context.registerReceiver(receiver, filter)
        }
        onDispose {
            try {
                context.unregisterReceiver(receiver)
            } catch (_: Exception) {
            }
        }
    }

    LaunchedEffect(Unit) { reload() }

    val backdrop = rememberLayerBackdrop()

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = MaterialTheme.colorScheme.background
    ) { padding ->
        Box(
            Modifier
                .fillMaxSize()
                .padding(padding)
                .layerBackdrop(backdrop) // 为 Liquid Glass 提供背景层
        ) {
            // 背景装饰（让玻璃效果有内容可折射）
            Box(
                Modifier
                    .fillMaxSize()
                    .background(MaterialTheme.colorScheme.background)
            )

            Column(
                Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp, vertical = 12.dp)
            ) {
                Text(
                    "Notification Logger",
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )
                Text(
                    "系统通知历史 · Material You + Liquid Glass",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Spacer(Modifier.height(16.dp))

                // ===== 状态按钮（Liquid Glass） =====
                LiquidGlassButton(
                    backdrop = backdrop,
                    onClick = {
                        context.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
                        Toast.makeText(context, "请开启 Notification Logger", Toast.LENGTH_LONG).show()
                    },
                    tint = if (listenerEnabled) Color(0xFF30D158) else Color(0xFFFF453A),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(
                        if (listenerEnabled) Icons.Default.CheckCircle else Icons.Default.Warning,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(Modifier.width(8.dp))
                    Text(
                        if (listenerEnabled) "通知使用权已开启" else "通知使用权未开启 – 点击开启",
                        color = Color.White,
                        fontWeight = FontWeight.Medium
                    )
                }

                Spacer(Modifier.height(14.dp))

                // ===== 筛选区域（Liquid Glass 卡片） =====
                LiquidGlassCard(
                    backdrop = backdrop,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(Modifier.padding(12.dp)) {
                        Text(
                            "按应用筛选",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(Modifier.height(6.dp))

                        val labels = listOf("全部应用") + packages.map { pkg ->
                            try {
                                context.packageManager
                                    .getApplicationLabel(
                                        context.packageManager.getApplicationInfo(pkg, 0)
                                    ).toString()
                            } catch (_: Exception) {
                                pkg
                            }
                        }

                        ExposedDropdownMenuBox(
                            expanded = filterExpanded,
                            onExpandedChange = { filterExpanded = it }
                        ) {
                            TextField(
                                value = if (selectedPackage == null) "全部应用"
                                else labels.getOrElse(packages.indexOf(selectedPackage) + 1) { selectedPackage!! },
                                onValueChange = {},
                                readOnly = true,
                                trailingIcon = {
                                    ExposedDropdownMenuDefaults.TrailingIcon(expanded = filterExpanded)
                                },
                                modifier = Modifier
                                    .menuAnchor(MenuAnchorType.PrimaryNotEditable)
                                    .fillMaxWidth(),
                                colors = ExposedDropdownMenuDefaults.textFieldColors()
                            )
                            ExposedDropdownMenu(
                                expanded = filterExpanded,
                                onDismissRequest = { filterExpanded = false }
                            ) {
                                DropdownMenuItem(
                                    text = { Text("全部应用") },
                                    onClick = {
                                        selectedPackage = null
                                        filterExpanded = false
                                        reload()
                                    }
                                )
                                packages.forEachIndexed { index, pkg ->
                                    DropdownMenuItem(
                                        text = { Text(labels[index + 1]) },
                                        onClick = {
                                            selectedPackage = pkg
                                            filterExpanded = false
                                            reload()
                                        }
                                    )
                                }
                            }
                        }
                    }
                }

                Spacer(Modifier.height(12.dp))

                // ===== 操作按钮 =====
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    LiquidGlassButton(
                        backdrop = backdrop,
                        onClick = { reload() },
                        tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.85f),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.Refresh, null, tint = Color.White, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("刷新", color = Color.White)
                    }
                    LiquidGlassButton(
                        backdrop = backdrop,
                        onClick = { showClearDialog = true },
                        tint = Color(0xFFFF453A).copy(alpha = 0.9f),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.Delete, null, tint = Color.White, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("清空", color = Color.White)
                    }
                }

                Spacer(Modifier.height(12.dp))

                // 计数
                Text(
                    "${logs.size} 条通知",
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier
                        .clip(RoundedCornerShape(50))
                        .background(MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.6f))
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                )

                Spacer(Modifier.height(10.dp))

                // ===== 列表 =====
                if (logs.isEmpty()) {
                    Box(
                        Modifier
                            .fillMaxSize()
                            .clip(RoundedCornerShape(16.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            "暂无通知记录\n\n1. 开启通知使用权\n2. 收到一些通知后这里会显示",
                            style = MaterialTheme.typography.bodyLarge,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(32.dp)
                        )
                    }
                } else {
                    LazyColumn(
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                        contentPadding = PaddingValues(bottom = 24.dp)
                    ) {
                        items(logs, key = { it.id }) { log ->
                            NotificationCard(
                                log = log,
                                backdrop = backdrop,
                                onClick = { detailLog = log }
                            )
                        }
                    }
                }
            }
        }
    }

    if (showClearDialog) {
        AlertDialog(
            onDismissRequest = { showClearDialog = false },
            title = { Text("确认清空") },
            text = {
                Text(
                    if (selectedPackage == null) "确定清空全部通知记录？"
                    else "确定清空当前应用的通知记录？"
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    if (selectedPackage == null) db.clearAll()
                    else db.clearByPackage(selectedPackage!!)
                    showClearDialog = false
                    reload()
                    Toast.makeText(context, "已清空", Toast.LENGTH_SHORT).show()
                }) { Text("确定") }
            },
            dismissButton = {
                TextButton(onClick = { showClearDialog = false }) { Text("取消") }
            }
        )
    }

    detailLog?.let { log ->
        val sdf = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
        AlertDialog(
            onDismissRequest = { detailLog = null },
            title = { Text("通知详情") },
            text = {
                Column {
                    Text("应用：${log.appName}")
                    Text("包名：${log.packageName}", fontFamily = FontFamily.Monospace, fontSize = 12.sp)
                    Spacer(Modifier.height(8.dp))
                    Text("时间：${sdf.format(Date(log.timestamp))}")
                    Spacer(Modifier.height(8.dp))
                    Text("标题：", fontWeight = FontWeight.Bold)
                    Text(log.title.ifEmpty { "(无标题)" })
                    Spacer(Modifier.height(8.dp))
                    Text("内容：", fontWeight = FontWeight.Bold)
                    Text(log.content.ifEmpty { "(无内容)" })
                }
            },
            confirmButton = {
                TextButton(onClick = { detailLog = null }) { Text("关闭") }
            }
        )
    }
}

/* ==================== Liquid Glass 组件 ==================== */

@Composable
fun LiquidGlassButton(
    backdrop: com.kyant.backdrop.Backdrop,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    tint: Color = Color.Unspecified,
    content: @Composable () -> Unit
) {
    Row(
        modifier = modifier
            .drawBackdrop(
                backdrop = backdrop,
                shape = { Capsule() },
                effects = {
                    vibrancy()
                    blur(8f.dp.toPx())
                    lens(16f.dp.toPx(), 32f.dp.toPx())
                },
                onDrawSurface = {
                    if (tint != Color.Unspecified) {
                        drawRect(tint, blendMode = BlendMode.Hue)
                        drawRect(tint.copy(alpha = 0.72f))
                    } else {
                        drawRect(Color.White.copy(alpha = 0.15f))
                    }
                }
            )
            .clickable(onClick = onClick)
            .height(48.dp)
            .padding(horizontal = 16.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
    ) {
        content()
    }
}

@Composable
fun LiquidGlassCard(
    backdrop: com.kyant.backdrop.Backdrop,
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit
) {
    Box(
        modifier = modifier
            .drawBackdrop(
                backdrop = backdrop,
                shape = { Capsule() },
                effects = {
                    vibrancy()
                    blur(12f.dp.toPx())
                    lens(10f.dp.toPx(), 20f.dp.toPx())
                },
                onDrawSurface = {
                    drawRect(Color.White.copy(alpha = 0.08f))
                }
            )
    ) {
        content()
    }
}

@Composable
fun NotificationCard(
    log: NotificationLog,
    backdrop: com.kyant.backdrop.Backdrop,
    onClick: () -> Unit
) {
    val timeText = remember(log.timestamp) {
        val sdfTime = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
        val sdfFull = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
        val now = System.currentTimeMillis()
        if (now - log.timestamp < 24 * 60 * 60 * 1000L) sdfTime.format(Date(log.timestamp))
        else sdfFull.format(Date(log.timestamp))
    }

    LiquidGlassCard(
        backdrop = backdrop,
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
    ) {
        Column(Modifier.padding(14.dp)) {
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    log.appName.ifEmpty { log.packageName },
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.primary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(8.dp))
                        .background(MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f))
                        .padding(horizontal = 8.dp, vertical = 3.dp)
                )
                Spacer(Modifier.width(8.dp))
                Text(
                    timeText,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Spacer(Modifier.height(8.dp))
            Text(
                log.title.ifEmpty { "(无标题)" },
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
            if (log.content.isNotEmpty()) {
                Spacer(Modifier.height(4.dp))
                Text(
                    log.content,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 3,
                    overflow = TextOverflow.Ellipsis
                )
            }
            Spacer(Modifier.height(6.dp))
            Text(
                log.packageName,
                style = MaterialTheme.typography.labelSmall,
                fontFamily = FontFamily.Monospace,
                color = MaterialTheme.colorScheme.outline,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

/* ==================== 工具 ==================== */

private fun isNotificationServiceEnabled(context: Context): Boolean {
    val pkgName = context.packageName
    val flat = Settings.Secure.getString(
        context.contentResolver,
        "enabled_notification_listeners"
    ) ?: return false
    return flat.split(":").any {
        val cn = ComponentName.unflattenFromString(it)
        cn != null && TextUtils.equals(pkgName, cn.packageName)
    }
}
