# Notification Logger 4.0

Material You + Liquid Glass 风格的系统通知记录器。

## 功能

- 监听系统所有通知（NotificationListenerService）
- 记录应用名、包名、标题、内容、时间
- **按应用筛选**
- 点击查看完整详情
- 刷新 / 清空（全部或当前应用）
- **Material 3（Material You）** 主题
- **Kyant0 AndroidLiquidGlass (backdrop)** 液态玻璃交互控件

## 技术栈

- Kotlin + Jetpack Compose
- Material 3
- [io.github.kyant0:backdrop](https://github.com/Kyant0/AndroidLiquidGlass) 2.0.0
- minSdk 26 / targetSdk 35

## 构建

适合 GitHub Actions / 本地 Android Studio：

```bash
./gradlew assembleDebug
```

## 使用

1. 安装并打开应用
2. 点击顶部状态按钮 → 开启「通知使用权」
3. 收到通知后自动出现在列表
4. 使用筛选下拉选择指定应用

## 依赖

```kotlin
implementation("io.github.kyant0:backdrop:2.0.0")
implementation("io.github.kyant0:shapes:1.2.0")
```
